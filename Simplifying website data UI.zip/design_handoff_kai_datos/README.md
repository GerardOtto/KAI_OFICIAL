# Handoff: KAI — Rediseño de pantallas de datos

## Overview

KAI muestra hoy casi todas sus pantallas con el mismo patrón: hero grande → grilla `lg:grid-cols-12` con sidebar de filtros (3 col) + tabla densa (9 col) → paginación. El resultado es que todas las pantallas se ven iguales, ninguna fila destaca, no hay escala visual para comparar valores y el usuario (investigadores/analistas) no puede responder su pregunta real:

> "¿Cómo mejoramos como institución y subimos en los rankings oficiales, y cómo estamos frente a otras universidades?"

Este handoff cubre cuatro pantallas rediseñadas:

| # | Pantalla | Ruta actual | Archivo fuente actual |
|---|---|---|---|
| 2a | **Resumen / Ranking** con selector de ranking en pestañas, score con barra de escala, Δ vs año anterior y sparkline de posición | `/ranking` | `src/pages/Ranking.jsx` |
| 2b | **Detalle de institución** (panel de brechas) con selector de universidad | nueva ruta, p.ej. `/institucion/:id` | nueva |
| 1d | **Directorio de investigadores** con perfil visual por fila | `/investigadores-pucv` y `/cientificos` | `src/pages/InvestigadoresPUCV.jsx`, `src/pages/Cientificos.jsx` |
| 1e | **Glosario** como matriz de pesos (heatmap) | `/metricas` | `src/pages/Metricas.jsx` |

Las opciones 1a y 1c son las versiones tempranas de 2a y 2b: **implementar 2a y 2b**, no 1a/1c.

## Screenshots

En `screenshots/`:

| Archivo | Qué muestra |
|---|---|
| `00-estado-actual-ranking.png` | Pantalla actual de Ranking (el "antes") |
| `2a-resumen-ranking.png` | 2a — Resumen con selector de ranking |
| `2b-detalle-institucion.png` | 2b — Detalle de institución / panel de brechas |
| `1d-directorio-investigadores.png` | 1d — Directorio de investigadores |
| `1e-glosario-matriz.png` | 1e — Glosario como matriz de pesos |

## About the Design Files

Los archivos `.dc.html` de este bundle son **referencias de diseño hechas en HTML** — prototipos que muestran el aspecto y el comportamiento buscados, **no código de producción para copiar**. Usan un runtime propio de streaming (`support.js`, etiquetas `<x-dc>`, `<sc-for>`, `<sc-if>`, holes `{{ }}`) que **no debe portarse**.

La tarea es **recrear estos diseños en el codebase existente**: React 18 + Vite + Tailwind + react-router, con los patrones ya establecidos (hooks `useXxx` que hacen fetch a la API, componentes en `src/components/`, páginas en `src/pages/`). Los `<sc-for>` son `.map()`, los `<sc-if>` son `&&`/ternarios, y los estilos inline se traducen a clases Tailwind.

Cómo abrir los prototipos: `npx serve` en esta carpeta y abrir cada `.dc.html` (necesitan `support.js` y `assets/` al lado).

## Fidelity

**Alta fidelidad (hifi).** Colores, tipografías, tamaños, espaciados y estados son finales y están tomados de `tailwind.config.js` del proyecto más un pequeño set nuevo de acentos. Recrear pixel-perfect usando Tailwind. Los **datos son placeholder plausible** — no son datos reales de la BD; hay que enlazarlos a los hooks.

---

## Design Tokens

### Existentes (ya en `tailwind.config.js`, no cambiar)

```js
background: "#131313"   // fondo de página
surface: "#1c1b1b"
surfaceHigh: "#2a2a2a"  // cards y tablas actuales
surfaceBright: "#3a3939"
outline: "#474747"
outlineSoft: "#919191"  // texto secundario
primary: "#ffffff"
fontFamily: { headline: ["Noto Serif","serif"], body: ["Manrope","sans-serif"], label: ["Inter","sans-serif"] }
```

### Nuevos (agregar a `tailwind.config.js`)

```js
colors: {
  panel:    "#171717",              // panel lateral del detalle (2b)
  hairline: "rgba(255,255,255,0.07)", // separador de filas
  accent:   "oklch(0.72 0.13 250)",  // azul: institución propia / valor destacado
  positive: "oklch(0.74 0.13 155)",  // verde: sobre el promedio, Δ positivo
  negative: "oklch(0.68 0.15 25)",   // rojo: bajo el promedio, Δ negativo
  warn:     "oklch(0.78 0.13 75)",   // ámbar: potencial / oportunidad
},
fontFamily: {
  mono: ["IBM Plex Mono","ui-monospace","monospace"], // TODAS las cifras
}
```

Agregar la fuente en `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

### Reglas tipográficas del rediseño

| Uso | Especificación |
|---|---|
| Título de pantalla | Noto Serif 600, 30px, `tracking-[-0.01em]`, `#fff` |
| Eyebrow / kicker | Manrope 400, 10px, uppercase, `letter-spacing:.16em`, `#8a8a8a` |
| Encabezado de columna | IBM Plex Mono 500, 9.5px, uppercase, `letter-spacing:.14em`, `#7a7a7a` |
| Nombre de institución/persona | Manrope 600, 14–15px, `#dcdcdc` (`#fff` si es la institución propia) |
| **Toda cifra** | IBM Plex Mono 500/600 + `font-variant-numeric: tabular-nums` |
| Score en tabla | Mono 500, 15px | 
| Cifra grande (posición) | Noto Serif 600, 46px, `line-height:1` |
| Texto de apoyo | Manrope 400, 11–13px, `line-height:1.6`, `#8a8a8a` |

Sin border-radius (salvo chips de topics: `rounded-full`) y sin sombras, coherente con el estilo duro actual. Separadores: `1px solid rgba(255,255,255,.05–.12)`.

### Espaciado

Padding de card 26–32px horizontal; filas de tabla `py-[11px] px-3`; gap de grilla 16px; secciones separadas 18–22px.

---

## Screens / Views

### 2a — Resumen / Ranking (reemplaza `/ranking`)

**Propósito:** ver la clasificación de un ranking, comparar scores de un vistazo y detectar movimiento año a año, con la institución propia siempre visible.

**Cambios estructurales respecto a hoy**
1. **Se elimina el sidebar `lg:col-span-3`.** El selector de rankings pasa a ser una fila de pestañas horizontales sobre la tabla; el año y la densidad son controles compactos a la derecha del título.
2. **Se elimina el hero de 64px de margen** (`mb-16` + h1 48px): título 30px con eyebrow, ~26px de padding superior.
3. **Se elimina la paginación**; scroll continuo (virtualizado sobre ~500 filas).
4. **Se elimina la columna "País" duplicada** (hoy el país aparece bajo el nombre *y* en su propia columna). El país va inline junto al nombre, en gris.
5. **El logo baja de 64px a 22px.** No aporta información y hoy domina la fila.
6. **La jerarquía de la fila** pasa a ser: score (mono 15px + barra) > nombre > Δ > posición > sparkline. Hoy el número de posición es Noto Serif 24px y compite con todo.
7. **Nada de "top 3 más brillante"**: la única fila destacada es la institución del usuario (PUCV), con `border-left: 2px solid accent` y fondo `rgba(70,130,255,.07)`.

**Layout**

- Header de app existente (`src/components/Header.jsx`), sin cambios.
- Contenedor: `max-w-[1600px] mx-auto px-8`.
- Bloque de título: eyebrow "Rankings institucionales" + h1 "Clasificación de universidades"; a la derecha, en fila: `{año} ▾`, `Densidad ⇕`, `Exportar` (chips 8px/12px, `bg-[#1c1c1c] border border-white/[.14] text-[#cfcfcf] text-[11px]`).
- Pestañas de ranking: fila `flex gap-1.5 flex-wrap`. Activa: `bg-white text-[#111] border-white font-semibold`; inactiva: `bg-[#1c1c1c] text-[#9a9a9a] border-white/[.12]`. Padding `9px 16px`, 11.5px Manrope 600.
- Bajo las pestañas, línea de contexto: descripción metodológica del ranking (izq., máx. 760px, 12px `#8a8a8a`) + total de instituciones (der., mono 10px uppercase). Separador `border-b border-white/[.12]`.
- Tabla como grilla CSS, **no `<table>`**: `grid-template-columns: 44px 1fr 210px 120px 150px`, `gap:16px`, `align-items:center`.

**Columnas**

| Col | Encabezado | Contenido |
|---|---|---|
| 44px | Pos | mono 13px tabular, `#8a8a8a` (`#fff` si es la institución propia), formato `01` |
| 1fr | Institución | tile logo 22px (background-image, `object-fit: contain` sobre `rgba(255,255,255,.06)`; si no hay logo, tile `rgba(255,255,255,.08)` con la inicial en 10px `rgba(255,255,255,.55)`) + nombre Manrope 600 14px truncado + país 11px `#6f6f6f` |
| 210px | Score en {ranking} | cifra mono 15px (ancho fijo 46px) + barra `flex-1 h-1.5 bg-white/[.07]`, relleno `width = score / maxScore * 100%`, color `accent` para la institución propia, `rgba(255,255,255,.28)` para el resto |
| 120px | Δ año ant. | mono 12.5px alineado a la derecha: `▲ n` en `positive`, `▼ n` en `negative`, `—` en `#6f6f6f` |
| 150px | Posición 2019—24 | sparkline SVG 140×26, `polyline` sin relleno, stroke 1.5px (`accent` propia / `rgba(255,255,255,.3)` resto). Eje Y invertido: posición 1 arriba |

Fila: `py-[11px] px-3`, `border-top: 1px solid rgba(255,255,255,.05)`, `border-left: 2px solid transparent` (accent para la propia). Hover: `bg-white/[.03]`, cursor pointer → navega a 2b.

Pie: "Mostrando 1–N · scroll continuo, sin paginación" (11px `#6f6f6f`) + enlace "Ver detalle de una institución →".

**Sparkline — cálculo exacto usado en el prototipo**

```js
// arr = posiciones por año, de más antigua a más reciente; escala fija 1..12
const points = arr
  .map((p, i) => `${(i * 140) / (arr.length - 1)},${2 + ((p - 1) / 11) * 22}`)
  .join(" ");
// <svg viewBox="0 0 140 26" width="140" height="26" preserveAspectRatio="none">
```

---

### 2b — Detalle de institución / panel de brechas (nueva ruta)

**Propósito:** responder "¿dónde ganamos y dónde perdemos puntos, y qué conviene atacar primero?". Es la pantalla que justifica el proyecto.

**Concepto clave:** cada métrica se ordena por **puntos recuperables = peso de la métrica × brecha contra el promedio del grupo de comparación**. Así el orden de la lista es el orden de prioridad, no el alfabético.

**Layout**

- Header de app.
- Barra de contexto (`py-[22px] px-8`, `border-b border-white/[.08]`, `flex items-end gap-3.5 flex-wrap`):
  - **Selector de institución** (min-width 420px): label mono 9.5px "Institución"; botón `bg-[#1c1c1c] border border-white/[.18] px-3.5 py-2.5` con tile de logo 24px + nombre Manrope 600 13px + `▾`. Al hacer clic abre un dropdown absoluto (`bg-[#1a1a1a] border border-white/[.18] shadow-[0_12px_32px_rgba(0,0,0,.5)]`, z-20) con campo de búsqueda y las opciones: tile 20px + nombre 12.5px; la seleccionada con `bg-white/[.07] text-white`.
  - **Comparar contra**: chip "Top 5 Chile ▾" (grupo de pares).
  - **Año**: chip mono con el año.
- Cuerpo: grilla `340px 1fr`.

**Panel izquierdo** (`bg-panel #171717`, `border-r border-white/[.08]`, `p-7`)
- Logo 40px + nombre en dos líneas (Manrope 600 13px, `leading-[1.35]`).
- Fila con dos bloques: **Posición** (Noto Serif 600 46px + Δ mono 12px coloreado) y **Score** (mono 22px).
- Nota: "Comparado con el promedio de las 5 instituciones chilenas mejor posicionadas." (12px `#8a8a8a`).
- Caja "Potencial total" (`bg-background border border-white/[.08] p-4`): cifra mono 600 30px en `warn` (`+7,9`) + "pts de score", y explicación: "si cerramos las brechas negativas hasta el promedio de pares. Equivale a ~2 posiciones."

**Panel derecho** (`p-7 px-8`)
- Título Noto Serif 22px "Brecha por métrica" + nota derecha "peso × brecha = puntos recuperables"; subtítulo "Ordenado por impacto en el score, no por nombre de métrica."
- Filas en grilla `230px 54px 1fr 76px`, `gap:14px`, `py-2.5`, `border-b border-white/[.06]`:
  1. Nombre de métrica (Manrope 600 12.5px `#e6e6e6`, truncado) + `{ranking} · peso {n}%` (10px `#6f6f6f`).
  2. Valor de la institución (mono 12px, derecha, tabular).
  3. **Barra divergente**: pista de 20px con línea central 1px `rgba(255,255,255,.16)` (implementada como `linear-gradient(to right, transparent 49.6%, rgba(255,255,255,.16) 49.6% 50.4%, transparent 50.4%)`); barra de 12px de alto, `left:50%` hacia la derecha si es positiva, `left: 50% − w` si es negativa, con `w = |pts| / maxAbs * 50%`. Color `positive` / `negative`.
  4. Puntos recuperables (mono 600 12px, color de la barra, formato `+2,1` / `−2,8`).
- Leyenda: cuadrados 10px + "Sobre el promedio de pares" / "Bajo el promedio".

---

### 1d — Directorio de investigadores (reemplaza las tablas de `/investigadores-pucv` y `/cientificos`)

**Propósito:** encontrar y comparar investigadores sin leer cinco columnas de números iguales.

**Cambios:** se eliminan las columnas Índice H / Documentos / Citas como celdas de texto y el sidebar de filtros; se eliminan las filas expandibles con topics (los topics se muestran siempre, los 3 principales). El buscador va arriba a la derecha; los filtros pasan a **chips con conteo**.

**Layout**

- Cabecera: eyebrow "Scopus · Censo institucional PUCV · N investigadores" + h2 Noto Serif 28px "Investigadores"; a la derecha input de búsqueda 260px (`bg-[#1c1c1c] border border-white/[.14] px-3 py-2.5 text-xs`) + chip de orden "Índice H ↓".
- Fila de facetas: chips `px-[11px] py-1.5 text-[11px]` con el conteo en mono 10.5px. Activa: `bg-white text-[#111]`; inactiva: `bg-white/[.04] border border-white/[.12] text-[#c4c4c4]`.
- Filas en grilla `1fr 96px 150px 300px`, `gap:20px`, `py-4`, `border-t border-white/[.07]`:
  1. Nombre Manrope 600 15px `#fff` + `{unidad} · {citas} citas` (11.5px `#7f7f7f`).
  2. **Índice H**: label mono 9px uppercase; cifra mono 600 19px + barra 34×5px (`bg-white/[.08]`, relleno `accent`, escala `h / 60`).
  3. **Docs 2019—24 · total**: label + mini barras de columna, 6 barras de 14px de ancho, `gap:3px`, alto `max(3px, v / 20 * 26px)`; el último año en `accent`, el resto `rgba(255,255,255,.22)`.
  4. **Topics**: chips `rounded-full px-[9px] py-1 text-[10.5px]` `bg-white/[.05] border border-white/[.1] text-[#c4c4c4]`, con el número de documentos en `#6f6f6f`. Máx. 3 visibles + "+N".

Para `/cientificos` (Top 2%) la misma fila, cambiando la columna 2 por **Rank global** (mono) y agregando campo/subcampo bajo el nombre.

---

### 1e — Glosario como matriz (reemplaza `/metricas`)

**Propósito:** entender qué mide cada ranking y cuánto pesa, sin recorrer ~40 tarjetas repetidas.

**Cambios:** desaparecen las tarjetas con `border-l-2` de color por ranking, la agrupación por ranking y el banner de filtros de 5 controles. Queda una matriz: **filas = dimensión de métrica, columnas = ranking**.

**Layout**

- Cabecera: eyebrow "Análisis transversal · {institución} · {año}"; h2 28px "Qué mide cada ranking, y cuánto pesa"; nota: "Intensidad = peso de la métrica en ese ranking. Número = valor {institución}. Celda vacía = el ranking no mide esa dimensión."
- Grilla `250px repeat(4, 1fr)`, `gap:6px`. Fila de encabezado con el nombre de cada ranking (mono 10px uppercase, centrado).
- Columna izquierda de cada fila: dimensión (Manrope 600 12.5px `#e6e6e6`) + pista (10.5px `#6f6f6f`, p.ej. "citas por publicación, FWCI").
- Celda: 56px de alto, `border 1px`, `p-2 px-2.5`, `flex-col justify-between`: peso arriba (mono 9.5px `rgba(255,255,255,.6)`, o "no mide" en `#5a5a5a`) y valor abajo (mono 600 15px `#fff`, `—` en `#6f6f6f`).
- **Heatmap:** `background: oklch(0.72 0.13 250 / α)` con `α = 0.08 + (peso / 25) * 0.42`; celda sin métrica: `rgba(255,255,255,.02)` con borde `rgba(255,255,255,.05)`.
- Leyenda: "Peso bajo" + 5 muestras de 26×10px (pesos 3/8/13/20/30%) + "Peso alto".
- Los botones **Descargar CSV / PDF** existentes (`handleCSV`, `handlePDF` en `Metricas.jsx`) se conservan, alineados a la derecha del título.

---

## Interactions & Behavior

- **2a → pestañas de ranking:** clic cambia `rankingId`; la tabla se reordena por el score de ese ranking, cambia el encabezado de la columna de score, el total de instituciones y la nota metodológica. Sin recarga de página.
- **2a → clic en fila:** navega al detalle de la institución (2b). Confirmar con el usuario si se abre en ruta propia o en panel lateral.
- **2a → Densidad:** alterna alto de fila cómodo (44px) / compacto (32px, sin logo).
- **2a → scroll:** carga continua; encabezado de columnas `sticky top-16` (bajo el header de 64px).
- **2b → selector de institución:** clic abre el dropdown (cerrar con Escape, clic fuera y al seleccionar); al seleccionar se recalculan posición, Δ, score, potencial total y todas las filas de brecha.
- **2b → "Comparar contra":** cambia el grupo de pares y por tanto el promedio, las brechas y el orden de la lista.
- **1d → chips de faceta:** filtran la lista y actualizan los conteos de las demás facetas; buscador con debounce ~250ms.
- **1e → celda:** hover muestra la descripción completa de la métrica (`descripcion_metrica`) en tooltip o panel lateral.
- **Estados:** cargando = skeleton de filas con la misma grilla (nunca un texto "Cargando..." centrado); vacío = frase + botón "Limpiar filtros"; error = mensaje con reintento. Transiciones 120–150ms `ease-out` en color/opacidad; nada de animación de layout.
- **Responsive:** el diseño está pensado para ≥1280px (herramienta de escritorio para analistas). Bajo 1024px: ocultar sparkline y Δ, y colapsar 2b a una columna.

## State Management

Por pantalla, siguiendo el patrón actual de hooks:

**2a:** `rankingId`, `anio`, `densidad`, `orden`, `seleccionadas[]` (para comparar). Se elimina `pagina`.
**2b:** `universidadId`, `grupoPares`, `anio`, `dropdownAbierto`.
**1d:** `search` (debounce), `facetas[]`, `orden`, `cursor` de scroll. Se elimina `pagina` y `expandido`.
**1e:** `universidadId`, `anio`, `celdaActiva`.

## Datos requeridos (lo que hoy falta en la API)

Los hooks existentes cubren buena parte, pero el rediseño necesita tres cosas nuevas:

1. **Serie histórica de posición y score por institución** — para Δ vs año anterior y el sparkline 2019—24.
   Hoy: `useRankingResumen(rankingId, anio)` devuelve un solo año.
   Necesario: `GET /rankings/:id/resumen?anio=X&historico=5` → por institución `{ id_universidad, nombre, pais, score_total, posicion, historico: [{anio, posicion, score}] }`. Alternativa sin backend: pedir N años en paralelo y unirlos en el cliente (aceptable para el prototipo, no para producción).
2. **Promedio del grupo de pares por métrica** — para las brechas de 2b.
   Necesario: `GET /universidades/:id/brechas?anio=X&grupo=top5_cl` → `[{ id_metrica, nombre_metrica, nombre_ranking, peso_metrica, valor, promedio_pares, brecha, puntos_recuperables }]`, ordenado por `puntos_recuperables`. Si no se puede en backend: con `useValoresMetricaUniversidad` para cada par y agregando en el cliente (más pesado).
3. **Documentos por año por investigador** — para las mini barras de 1d.
   Necesario: agregar `documentos_por_anio: [{anio, n}]` al payload de `useCientificos`, o `GET /cientificos/:id/produccion`.

Cálculos que van en el cliente (`src/utils/`):
```js
// puntos recuperables
puntos = (peso_metrica / 100) * (valor_normalizado − promedio_pares_normalizado)
// potencial total = suma de |puntos| de las métricas con puntos < 0
```
Cuidado: las métricas tienen escalas distintas (0–100, FWCI ~1, conteos). Normalizar por métrica (min-max sobre el grupo de comparación) antes de multiplicar por el peso; si no, la barra divergente miente. Es la decisión técnica más importante de 2b — validarla con quien conozca la metodología de los rankings.

## Assets

- `assets/logo.png` — logo KAI, copiado de `src/assets/logo.png`. Se renderiza con `filter: invert(1); mix-blend-mode: screen`, alto 30–36px.
- `assets/logos/1.jpg` (PUC Chile), `2.jpg` (PUCV), `4.jpg` (UAI) — copiados de `public/logos/`. En producción se sigue usando `getLogoUrl(idUniversidad)` de `src/utils/logos.js`.
- **Sin iconos nuevos.** Los prototipos usan los mismos SVG inline que ya existen en las páginas, más glifos de texto (`▲ ▼ — ▾ ⇕`). Si se prefieren iconos reales, usar `public/icons.svg`.
- Importante: los tiles de logo se pintan con `background-image` (no `<img>`), con fallback a tile con la inicial — el mismo comportamiento de `src/components/UniversidadLogo.jsx`.

## Files

- `KAI — Rediseño de Datos.dc.html` — el rediseño. Turno 2 (arriba): **2a** Resumen y **2b** Detalle de institución, ambos interactivos. Turno 1 (abajo): 1a, 1c (versiones tempranas de 2a/2b), **1d** Directorio y **1e** Glosario.
- `KAI — Estado Actual.dc.html` — recreación fiel de las pantallas actuales (Ranking, Científicos, Investigadores PUCV, Glosario); el nav del header cambia de pantalla. Útil como antes/después.
- `support.js`, `assets/` — runtime y assets necesarios para abrir los prototipos.

Archivos del codebase que hay que tocar: `src/pages/Ranking.jsx`, `src/pages/Cientificos.jsx`, `src/pages/InvestigadoresPUCV.jsx`, `src/pages/Metricas.jsx`, `tailwind.config.js`, `index.html`, `src/App.jsx` (nueva ruta de detalle), y nuevos componentes sugeridos: `src/components/data/RankingTable.jsx`, `ScoreBar.jsx`, `Sparkline.jsx`, `DivergingBar.jsx`, `MiniBars.jsx`, `HeatCell.jsx`, `UniversidadPicker.jsx`, `FacetChips.jsx`.

## Orden sugerido de implementación

1. Tokens + fuente mono + los componentes atómicos (`ScoreBar`, `Sparkline`, `DivergingBar`, `MiniBars`, `HeatCell`).
2. **2a** con los datos que ya existen (score y posición del año actual); Δ y sparkline detrás de un flag hasta que llegue el histórico.
3. **1e** (solo requiere datos existentes: pesos + valores).
4. **1d** (mini barras detrás de flag hasta tener documentos por año).
5. **2b** al final: depende del endpoint de brechas y de la decisión de normalización.
